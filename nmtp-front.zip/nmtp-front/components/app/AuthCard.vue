<template>
    <div class="auth-card">
        <slot />
    </div>
</template>