export interface RocketBet{
    win: boolean,
    balance: number,
    message: string
    animTime: number,
    coef: number,
    wonLostAmount: number,
}