export interface UserRatingResponse{
    users: UserRating[],
    current: UserRating?
}