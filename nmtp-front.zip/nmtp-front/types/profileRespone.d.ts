export interface ProfileResponse{
    login: string,
    registrationDate: string,
    balance: number
}