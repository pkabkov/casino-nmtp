export interface UserRating {
  place: number
  username: string
  rating: number
}
