export interface RocketBetCard {
  bet: number,
  coef: number
}