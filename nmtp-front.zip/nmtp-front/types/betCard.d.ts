export interface BetCard {
  bet: number,
  cell: number,
}