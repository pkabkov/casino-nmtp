export interface MineSweeperBet{
    win: boolean,
    balance: number,
    message: string,
    coef: number,
    wonLostAmount: number,
}