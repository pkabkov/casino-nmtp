export interface GameRecord{
    date: string,
    score: number
}