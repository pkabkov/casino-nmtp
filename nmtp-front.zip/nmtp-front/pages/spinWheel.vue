<script lang="ts" setup>

</script>
<template>
  <h1>Крути барабан</h1>
</template>
<style scoped>

</style>