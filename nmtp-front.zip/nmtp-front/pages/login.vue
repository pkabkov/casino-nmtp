<script lang="ts" setup>

</script>
<template>
  <AppLoginCard />
</template>
<style scoped>

</style>