<template>
  <AppSignupCard/>
</template>