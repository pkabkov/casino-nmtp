declare module '#auth-utils/' {
  interface User {
    id: string
    balance?: number
  }
}